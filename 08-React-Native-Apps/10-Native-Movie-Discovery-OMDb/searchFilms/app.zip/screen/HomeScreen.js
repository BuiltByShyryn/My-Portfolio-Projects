import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

export default function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Это главный экран</Text>
      <TouchableOpacity
        style={styles.btn}
        onPress={() => navigation.navigate("Detail")}
      >
        <Text style={styles.btn__text}>Перейти на экран деталей</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#474747ff",
  },
  text: {
    fontSize: 20,
    fontWeight: 700,
    color: "#fff",
  },
  btn: {
    width: 250,
    height: 45,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#fff",
    borderRadius: 10,
    marginVertical: 20,
  },
  btn__text: {
    color: "#3b3b3bff",
    fontSize: 16,
  },
});
