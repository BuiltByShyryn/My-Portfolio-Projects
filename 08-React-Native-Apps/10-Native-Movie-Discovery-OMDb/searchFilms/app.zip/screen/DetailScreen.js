import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

export default function DetailScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Экран деталей</Text>
      <TouchableOpacity style={styles.btn} onPress={() => navigation.goBack()}>
        <Text style={styles.btn__text}>Вернуться назад</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#474747ff",
  },
  text: {
    fontSize: 20,
    fontWeight: 700,
    color: "#fff",
  },
  btn: {
    width: 200,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#fff",
    borderRadius: 10,
    marginVertical: 20,
  },
  btn__text: {
    color: "#3b3b3bff",
    fontSize: 16,
  },
});
